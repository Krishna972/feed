const dotenv = require('dotenv');
dotenv.config();
const connectionParams = {
    useNewUrlParser: true,
    useUnifiedTopology: true,
};
const mongoose = require('mongoose');
mongoose.connect(process.env.DB_CONNETC,connectionParams).then(()=>{
    console.log(`mongodb connected`);
}).catch((err)=>{
    console.log(`not connected ${err}`);
});