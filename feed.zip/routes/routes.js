const express = require("express");
const router = express.Router();
const dummy = require('../schema/feedschema')
const { read } = require('feed-reader')
const url = process.env.RSSURL;
const feedschema = require('../schema/feedschema')
/**
 * This method is used to check the searched keyword in our database.
 *
 */
const getDbData = async(data)=> {
    const dbdata =await feedschema.find({title:{ $regex : data }})
    return dbdata;
}

/**
 * This API wil checked the key word from database if data exits it will return.
 * If data not exits in databse it will insert searched data in datbase.
 * @returns 
 */

router.get('/api/data', async (req, res) => {
   const data = await getDbData(req.body.search)
    if(data.length<=0){
        read(url).then((feed) => {
            const search = feed.entries.filter(i => i.title.includes(req.body.search))
            feedschema.create(search).then(data => {
                res.send(data)
            })}).catch((err) => {
               res.status(500).json(err.message);
              })
    } else 
    {
        res.status(500).json(data);
    }
})

module.exports = router;