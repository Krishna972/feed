const express = require("express");

require('./config/dbcon');
const app = express();
const dotenv = require("dotenv");
dotenv.config();
const port  = process.env.PORT ||  2000;
app.use(express.json());
const routeRouter = require('./routes/routes')
app.use(routeRouter);
app.listen(port,()=>{
    console.log(`Server is running on ${port}`);
})