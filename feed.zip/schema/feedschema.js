const mongoose = require("mongoose");

const feedschema = new mongoose.Schema(
  {
    title: { type: String },
    link: { type: String },
    description: { type: String},
    published: { type: String },
   
  },
  { timestamps: true }
);
module.exports = mongoose.model("feeds", feedschema);
